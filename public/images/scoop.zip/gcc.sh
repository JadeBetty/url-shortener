scoop install gcc
scoop bucket add main
scoop install neovim